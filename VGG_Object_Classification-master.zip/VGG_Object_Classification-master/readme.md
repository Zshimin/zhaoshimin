Pre trained VGG model to classify objects/photographs
This is a simple code for Object detection and its implementation in Keras using the VGG-16 model preloaded in the keras library and giving out the Top 5 labels predicted.

Credits https://machinelearningmastery.com/use-pre-trained-vgg-model-classify-objects-photographs/

Currently it just takes one Photo/image hardcoded in the program.

Give TOP 5 results in terms of Label:-
